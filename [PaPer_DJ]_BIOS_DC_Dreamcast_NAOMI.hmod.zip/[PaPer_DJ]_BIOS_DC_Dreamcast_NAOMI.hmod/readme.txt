﻿=== SEGA DREAMCAST BIOS === (4.12Mb)
(Working on Libretro/Retroarch)

>> Compiled By PaPer_DJ <<

Includes "dc_boot.bin" - "dc_flash.bin" - "naomi_boot.bin" 

-------------------------------------------

USE WITH RETROARCH "DC" Dreamcast CORES (Reicast)