﻿=== Neo Geo UniBIOS V 3.3 === (1.69Mb)
(Working on FBA NEOGEO ROMSET)

>> Embedded By PaPer_DJ <<

Includes "neogeo_old.zip" 
(Legacy MAME2003 NEOGEO BIOS) 

and "neogeo.zip" 
(FBA NEOGEO BIOS with UNIBIOS 3.3 Embedded)

Para usar únicamente el sistema embebido de UNIBIOS se pueden borrar el resto de ficheros "neogeo_xxx.zip"
Sólo es necesario el fichero "neogeo.zip" dentro del directorio /system

SI NO SE QUIERE USAR UNIBIOS para opciones adicionales y trucos se puede usar en su lugar la BIOS "neogeo.zip" de FBA inlcuida en otro MOD.
(Las ROMS cargarán un pelín más rápidas)
------------------------------------------------------
##Para que sirve Unibios:

REGION - Cambiar la región del sistema (Europa/USA/Japón) y el modo de sistema (AES/MVS)
CONFIG - Acceder a las configuraciones del sistema, para poder cambiar la dificultad/número de vidas/Tiempo-etc
TRUCOS - Acceso a una base de datos de trucos *Acceso a reproductor de música.....y mucho más!

###Para FBA libretro

Inicia cualquier juego de NEO-GEO, verás la pantalla de inicio de UNIVERSE BIOS
Durante esta pantalla, mantén apretado C + B + A ( XBA) para cambio de región - Para salir presiona C
Para acceder al menú de juego, manten precionado C + B + A (XBA) + START al mismo tiempo
Para acceder al menú de configuraciones en FBA Libreto, Durante la pantalla de inicio UNIVEESE BIOS, mantén presionado A+X+Y

##También se puede ENTRAR A LA CONFIGURACIÓN DE UNIBIOS simplemente entrando en el menú de retroarch y saliendo durante el juego.
Antes de volver al juego mostrará la pantalla de configuración de UNIBIOS

------------------------------------------------------
The following codes should be used on the 1up controller while the splash screen is showing or held during power up if the splash screen is disabled; 
  
     (A)+(B)+(C)		UNIVERSE BIOS Menu

     (A)+(B)+(C)+(D)		Memory Card Manager

     (B)+(C)+(D)		Test Mode (MVS only)

     (B)+(C)+(D)		HW Test (AES only)

     (Use 2up controller for the following code)
      (A)+(B)+(C)+(D)	Controller Test (AES only)

The following codes are available in game only, they will not work if you have disabled the in game menu (general bios settings); 	Continue >> ↓↓↓⇓⇩↓↓↓
  
    (START)+(SELECT)	In Game Menu

    (START)+(COIN)	In Game Menu

    (START)+(A)+(B)+(C)	In Game Menu

http://unibios.free.fr/download.html

Download v3.3 for MVS / AES 
This latest free version of the Universe Bios above was released on 06/05/2018. 

Further information on using the UNIVERSE BIOS is provided in the manual that came with the UNIVERSE BIOS or in the readme.txt included with the image. 

-------------------------------------------------------

BIOS NEOGEO PARA FBALPHA 	http://www.gametronik.com/site/emulation/FBA/
				http://www.gametronik.com/site/rubriques/FBA/Bios/neogeo.zip

UNIBIOS PARA EMBEBER EN BIOS	http://unibios.free.fr/index.html
				http://unibios.free.fr/download.html

Mini Tuto Embeber UNIBIOS	https://github.com/recalbox/recalbox-os/wiki/Usar-Unibios-en-Neo-Geo-(ES)