﻿=== PCENGINE CD MULTI REGION BIOS === (256Kb)
(Working on Libretro/Retroarch)

>> Compiled By PaPer_DJ <<


Includes "syscard3.pce"

-------------------------------------------

USE WITH RETROARCH PCENGINE CORES