﻿=== SEGA 32X & SEGA MEGA CD MULTI REGION BIOS === (387kB)
(Working on Libretro/Retroarch)

>> Compiled By PaPer_DJ <<

Includes SEGA 32X "32X_G_BIOS.BIN" - "32X_M_BIOS.BIN" - "32X_S_BIOS.BIN" 

Includes MEGA CD "eu_mcd2_9306.bin" - "jp_mcd1_9112.bin" - "us_scd2_9306.bin"

-------------------------------------------

USE WITH RETROARCH SEGA 32X & MEGA CD CORES