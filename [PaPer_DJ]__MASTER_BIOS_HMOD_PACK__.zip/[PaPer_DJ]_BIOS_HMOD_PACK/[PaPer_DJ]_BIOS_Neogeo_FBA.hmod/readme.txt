﻿=== Neo Geo FBA BIOS === (1.42Mb)
(Working on FBA NEOGEO ROMSET)

>> Compiled By PaPer_DJ <<

Includes "neogeo.zip" 

NORMAL FBA NEOGEO BIOS (Final Burn Alpha) 
(NOT UNIBIOS)

-------------------------------------------

BIOS NEOGEO PARA FBALPHA 	

http://www.gametronik.com/site/emulation/FBA/

http://www.gametronik.com/site/rubriques/FBA/Bios/neogeo.zip