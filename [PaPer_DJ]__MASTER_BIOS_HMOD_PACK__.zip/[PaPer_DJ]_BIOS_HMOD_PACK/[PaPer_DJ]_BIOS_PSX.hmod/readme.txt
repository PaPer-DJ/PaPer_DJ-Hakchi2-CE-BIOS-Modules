﻿=== PSX MULTI REGION BIOS === (1.50Mb)
(Working on Libretro/Retroarch)

>> Compiled By PaPer_DJ <<

Includes "scph5500.bin" - "scph5501.bin" - "scph5502.bin" 

-------------------------------------------

USE WITH RETROARCH PSX/PSP CORES